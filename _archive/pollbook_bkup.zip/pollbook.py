from tkinter import *
from random import randint
from tkinter import filedialog
from tkinter import messagebox
from tkinter import ttk
import os, sys


from db import Database
db = Database('store.db')


#Browse dir
def dir_browse():
	resp = new_file_validation() 
	if resp != '':
		messagebox.showerror("Validation Error:", resp)
		return

	file_name =  filedialog.askopenfilename(initialdir = "/",title = "Select file",filetypes = (("all files","*.*"),("jpeg files","*.jpg")))
	if file_name != "":
		new_frame.pack_forget()
		import_file(file_name)
	else:
		return

# Create Popup function
def import_file(file_name):
	hide_menu_frames()
	sqlite_import.pack(fill="both", expand=1)

	f = os.path.basename(file_name)
	mess = f"Importing {f} ....."
	slqlite_flash = Label(sqlite_import, text=f"{mess}", font=("helvetica", 14))
	slqlite_flash.pack(pady=10)

	# ProgressBar
	global my_progress 
	my_progress = ttk.Progressbar(sqlite_import, orient=HORIZONTAL, length=300, mode="determinate")
	my_progress.pack(pady=10)
	global percent
	percent = Label(sqlite_import, text="", anchor=S, font=("helvetica", 12))
	percent.pack(pady=5)

	response = messagebox.askokcancel("Importing CSV File", f'Import File {f} ? ')
	if response == 1:
		db.csv_to_sqlite(file_name, f, my_progress, percent, messagebox)
	else:
		new_file() # return	display results		


#Create our new_file function
def new_file():
	reset_run_frame(new_frame)

	# Page Header 
	text_mess = "Create New Pollbook: Import New File."
	my_flash = Label(new_frame, text=f"{text_mess}", font=("helvetica", 14))
	my_flash.pack(pady=10)

	# Get Inputs
	global project_name 
	project_name_lbl = Label(new_frame, text="Project Name", font=("helvetica", 12)).pack(pady=10)	
	project_name = Entry(new_frame, font=("helvetica", 12))
	project_name.pack(ipadx=100, ipady=6)
	global project_account 
	project_account_lbl = Label(new_frame, text="Account Name", font=("helvetica", 12)).pack(pady=10)	
	project_account = Entry(new_frame, font=("helvetica", 12))
	project_account.pack(ipadx=100, ipady=6)
	global project_contact
	project_contact_lbl = Label(new_frame, text="Contact Name", font=("helvetica", 12)).pack(pady=10)	
	project_contact = Entry(new_frame, font=("helvetica", 12))
	project_contact.pack(ipadx=100, ipady=6)
	global project_username
	project_username_lbl = Label(new_frame, text="Username", font=("helvetica", 12)).pack(pady=10)	
	project_username = Entry(new_frame, font=("helvetica", 12))
	project_username.pack(ipadx=100, ipady=6)

	# Buttons
	add_btn = Button(new_frame, text='Get File', width=12, command=dir_browse).pack(pady=10)



#Create our open_file function
def open_file():
	text_mess = "Open Project: Select Job Folder"	
	reset_run_frame(open_frame, text_mess)


def reset_run_frame(frame_opt):
	hide_menu_frames()
	frame_opt.pack(fill="both", expand=1)


# Hide Frame Function
def hide_menu_frames():
	# Destroy the children widgets in each frame
	for widget in new_frame.winfo_children():
		widget.destroy()
	for widget in open_frame.winfo_children():
		widget.destroy()
	for widget in start_frame.winfo_children():
		widget.destroy()
	for widget in sqlite_import.winfo_children():
		widget.destroy()

	# Hide all frames
	new_frame.pack_forget()
	open_frame.pack_forget()
	start_frame.pack_forget()
	sqlite_import.pack_forget()

# Start Screen
def home():
	hide_menu_frames()
	start_frame.pack(fill="both", expand=1)
	start_label = Label(start_frame, text="Election Poll Books", font=("Helvetica", 18)).pack(pady=40)

#Form Validation
def new_file_validation():
	fld_names = [('Project Name', project_name),('Account Name', project_account), ('Contact Name', project_contact), ('Username', project_username)]
	
	error_mess = ''
	for fld_name in fld_names:
		if fld_name[1].get() == '':
			error_mess += f"\n{fld_name[0]} empty and is required\n"

	return error_mess


	sys.exit(f"Quit App.............")

def get_attributes(widget):
	widg = widget
	keys = widg.keys()
	for key in keys:
		print("Attribute: {:<20}".format(key), end=' ')
		value = widg[key]
		vtype = type(value)
		print('Type: {:<30} Value: {}'.format(str(vtype), value))



#####################################################
# Create Tk Window
#####################################################
root = Tk()
root.title("Flashcard App!")
# root.resizable(False, False)
# root.geometry("900x400")
root.geometry("800x700")

# Gets the requested values of the height and widht.
windowWidth = root.winfo_reqwidth()
windowHeight = root.winfo_reqheight()
print("Width",windowWidth,"Height",windowHeight)
 
# Gets both half the screen width/height and window width/height
positionRight = int(root.winfo_screenwidth()/3 - windowWidth/2)
positionDown = int(root.winfo_screenheight()/3 - windowHeight/2)
 
# Positions the window in the center of the page.
root.geometry("+{}+{}".format(positionRight, positionDown))
# root.iconbitmap('c:/guis/exe/codemy.ico')

##################
# global options #
##################
project_name = StringVar()
project_account = StringVar()
project_contact = StringVar()
project_username = StringVar()

#Define Main Menu
my_menu = Menu(root)
root.config(menu=my_menu)

# Create menu items
poll_menu = Menu(my_menu, tearoff=0)
my_menu.add_cascade(label="File", menu=poll_menu)
poll_menu.add_command(label="Create Poll Book", command=lambda: new_file())
poll_menu.add_command(label="Open Poll Book", command=lambda: open_file())
poll_menu.add_separator()
poll_menu.add_command(label="Close Files", command=lambda: home())
poll_menu.add_separator()
poll_menu.add_command(label="Exit", command=root.quit)

# Create menu items
print_menu = Menu(my_menu)
my_menu.add_cascade(label="Print Files", menu=print_menu)
print_menu.add_command(label="New Poll Book", command=lambda: new_file())
print_menu.add_command(label="Open Poll Book", command=lambda: open_file())
print_menu.add_separator()
print_menu.add_command(label="Close Files", command=lambda: home())
print_menu.add_separator()
print_menu.add_command(label="Exit", command=root.quit)


# Create Math Frames
new_frame = Frame(root) #, highlightbackground="black", highlightthickness=1
open_frame = Frame(root)
start_frame = Frame(root)
sqlite_import =Frame(root)

# Show the start screen
home()

root.mainloop()